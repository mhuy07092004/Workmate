/**
 * Navbar.jsx — Top navigation bar
 *
 * Three zones:
 *   Left  — Workmate brand logo
 *   Center — Search bar (expands on focus, shows advanced filter popover)
 *   Right  — Notification bell + user dropdown (signed in) OR "Join Now" button (signed out)
 *
 * Auth state is read from localStorage ('workmate_token').
 * Sign-out clears the JWT + cached user info and redirects to /login.
 *
 * Search bar behaviour:
 *   - Collapsed: standard rounded pill input.
 *   - Expanded (on focus): bar widens and an advanced filter panel drops below.
 *   - Collapse on: Escape key, or click outside the search + panel area.
 *   - Filter state is local (UI only). The typed query is bound to
 *     filters.jobTitle (candidate) or filters.candidateName (employer) so
 *     those fields are suppressed inside the popover to avoid duplication.
 *
 * BACKEND DEV NOTE: Wire search here when ready.
 *   - Candidate search: POST /api/jobs/search  { q: filters.jobTitle, ...filters }
 *   - Employer search:  POST /api/candidates/search { q: filters.candidateName, ...filters }
 *   - Apply button in JobFilter / CandidateFilter should trigger the fetch and
 *     navigate to a /search-results page (or update the dashboard in-place).
 *   - State shape already matches what the recommended pages use; no refactor needed.
 *   - grep "BACKEND DEV" to find all handoff points.
 */
import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { clearCurrentUser, getCurrentUserRole } from '../../services/userService.js'
import JobFilter from '../FilterSection/JobFilter.jsx'
import CandidateFilter from '../FilterSection/CandidateFilter.jsx'

/** Dropdown items for candidates */
const CANDIDATE_DROPDOWN_ITEMS = [
  { label: 'Your Profile', key: 'profile', path: '/profile' },
  { label: 'Settings', key: 'settings', path: '/settings' },
  { label: 'My Applications', key: 'applications', path: '/applications' },
  { label: 'My Networks', key: 'networks', path: '/mynetwork' },
  { label: 'Post', key: 'post', path: '/post' },
  { label: 'News', key: 'news', path: '/news' },
]

/** Dropdown items for employers */
const EMPLOYER_DROPDOWN_ITEMS = [
  { label: 'Your Profile', key: 'profile', path: '/profile' },
  { label: 'Settings', key: 'settings', path: '/settings' },
  { label: 'Applicants', key: 'applications', path: '/applications' },
  { label: 'Post', key: 'post', path: '/post' },
  { label: 'News', key: 'news', path: '/news' },
]

/** Navigation buttons for candidates */
const CANDIDATE_NAV_BUTTONS = [
  { label: 'Home', path: '/dashboard' },
  { label: 'Help', path: '/help' },
  { label: 'Recommended Jobs', path: '/recommended-jobs' },
  { label: 'Subscription', path: '/subscription' },
]

/** Navigation buttons for employers */
const EMPLOYER_NAV_BUTTONS = [
  { label: 'Home', path: '/dashboard' },
  { label: 'Help', path: '/help' },
  { label: 'Post a Job', path: '/post-job' },
  { label: 'Recommended Candidates', path: '/recommended-candidates' },
  { label: 'Subscription', path: '/subscription' },
]

// BACKEND DEV NOTE: Replace with API call to fetch real notifications
// GET /api/notifications?limit=4&sort=recent
const MOCK_NOTIFICATIONS = [
  { id: 1, text: 'Hayden Loi Just got his first job !', time: '10m ago', unread: true },
  { id: 2, text: 'SpaceX just launch a new Robot', time: '1h ago', unread: true },
  { id: 3, text: 'Minh just applied to "Fresher Front..."', time: '2h ago', unread: true },
  { id: 4, text: 'Your Post Reached 1000 candidates', time: '4d ago', unread: false },
]

const INITIAL_JOB_FILTERS = {
  location: '',
  salaryRange: '',
  jobCategory: '',
  industry: '',
  jobTitle: '',
  employmentType: '',
  companyName: '',
  workArrangement: '',
  certification: '',
  language: '',
  degree: '',
  dayPosted: '',
  experience: '',
  roleLevel: '',
  sortBy: 'Most Recent',
}

const INITIAL_CANDIDATE_FILTERS = {
  candidateName: '',
  location: '',
  experienceLevel: '',
  degreeType: '',
  major: '',
  certification: '',
  language: '',
  workArrangement: '',
  industry: '',
  roleLevel: '',
  availability: '',
  sortBy: 'Most Relevant',
}

const dropdownItemClass =
  'block w-full cursor-pointer rounded-lg border-0 bg-transparent px-3.5 py-2.5 text-left text-[0.92rem] font-medium text-slate-800 transition-colors hover:bg-slate-100'

const dropdownSignOutClass =
  'block w-full cursor-pointer rounded-lg border-0 bg-transparent px-3.5 py-2.5 text-left text-[0.92rem] font-semibold text-red-600 transition-colors hover:bg-red-50'

function Navbar() {
  const navigate = useNavigate()
  const location = useLocation()

  const [isSignedIn, setIsSignedIn] = useState(() => !!localStorage.getItem('workmate_token'))
  const [userRole, _setUserRole] = useState(() => getCurrentUserRole())
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [notificationsOpen, setNotificationsOpen] = useState(false)

  // Search bar expand state
  const [searchExpanded, setSearchExpanded] = useState(false)
  const [showSearchFilters, setShowSearchFilters] = useState(false)
  const [jobFilters, setJobFilters] = useState(INITIAL_JOB_FILTERS)
  const [candidateFilters, setCandidateFilters] = useState(INITIAL_CANDIDATE_FILTERS)

  const dropdownRef = useRef(null)
  const notificationsRef = useRef(null)
  const searchRef = useRef(null)

  const isEmployer = userRole === 'employer'
  const searchPlaceholder = isEmployer ? 'Search Candidates' : 'Search Jobs'
  const searchAriaLabel = isEmployer ? 'Search candidates' : 'Search jobs'

  const searchInputValue = isEmployer ? candidateFilters.candidateName : jobFilters.jobTitle

  const dropdownItems = useMemo(() => {
    return isEmployer ? EMPLOYER_DROPDOWN_ITEMS : CANDIDATE_DROPDOWN_ITEMS
  }, [isEmployer])

  const navButtons = useMemo(() => {
    return isEmployer ? EMPLOYER_NAV_BUTTONS : CANDIDATE_NAV_BUTTONS
  }, [isEmployer])

  const unreadCount = useMemo(() => {
    return MOCK_NOTIFICATIONS.filter(n => n.unread).length
  }, [])

  /** Close dropdowns and search panel when clicking outside */
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false)
      }
      if (notificationsRef.current && !notificationsRef.current.contains(event.target)) {
        setNotificationsOpen(false)
      }
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setSearchExpanded(false)
        setShowSearchFilters(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  /** Collapse search on Escape key */
  useEffect(() => {
    function handleKeyDown(e) {
      if (e.key === 'Escape' && searchExpanded) {
        setSearchExpanded(false)
        setShowSearchFilters(false)
      }
    }
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [searchExpanded])

  const handleSearchInput = (e) => {
    const value = e.target.value
    if (isEmployer) {
      setCandidateFilters(prev => ({ ...prev, candidateName: value }))
    } else {
      setJobFilters(prev => ({ ...prev, jobTitle: value }))
    }
  }

  const handleJobFilterChange = (key, value) => {
    setJobFilters(prev => ({ ...prev, [key]: value }))
  }

  const handleClearJobFilters = () => {
    setJobFilters(INITIAL_JOB_FILTERS)
  }

  const handleApplyJobFilters = () => {
    setSearchExpanded(false)
    setShowSearchFilters(false)
    navigate('/recommended-jobs', { state: jobFilters })
  }

  const handleCandidateFilterChange = (key, value) => {
    setCandidateFilters(prev => ({ ...prev, [key]: value }))
  }

  const handleClearCandidateFilters = () => {
    setCandidateFilters(INITIAL_CANDIDATE_FILTERS)
  }

  const handleSignOut = () => {
    clearCurrentUser()
    setIsSignedIn(false)
    setDropdownOpen(false)
    navigate('/login', { replace: true })
  }

  return (
    <header className="sticky top-0 z-[100] flex h-16 items-center gap-4 border-b border-gray-200 bg-white px-6">
      {/* Brand logo */}
      <button
        type="button"
        onClick={() => navigate('/dashboard')}
        className="flex shrink-0 cursor-pointer items-center gap-2.5 border-0 bg-transparent p-0 text-slate-900 no-underline"
      >
        <span className="inline-flex h-[34px] w-[34px] items-center justify-center rounded-lg bg-blue-700 text-base font-bold text-white">
          W
        </span>
        <span className="text-[1.15rem] font-bold text-slate-900">Workmate</span>
      </button>

      {/* Center: expandable search bar */}
      <div
        ref={searchRef}
        className={`relative mx-auto flex-1 transition-[max-width] duration-300 ease-in-out ${
          searchExpanded ? 'max-w-[680px]' : 'max-w-[480px]'
        }`}
      >
        {/* Search input */}
        <div className="relative flex items-center">
          <span
            className="pointer-events-none absolute left-3.5 flex items-center text-slate-400"
            aria-hidden="true"
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
          </span>
          <input
            className="w-full rounded-full border-[1.5px] border-slate-200 bg-slate-50 py-[9px] pr-4 pl-10 text-[0.95rem] text-slate-900 outline-none transition-[border-color,box-shadow,background-color] placeholder:text-slate-400 focus:border-blue-600 focus:bg-white focus:shadow-[0_0_0_3px_rgba(37,99,235,0.12)]"
            type="search"
            placeholder={searchPlaceholder}
            aria-label={searchAriaLabel}
            aria-expanded={searchExpanded}
            value={searchInputValue}
            onChange={handleSearchInput}
            onFocus={() => setSearchExpanded(true)}
          />
          {searchExpanded && (
            <button
              type="button"
              onClick={() => {
                setSearchExpanded(false)
                setShowSearchFilters(false)
              }}
              className="absolute right-3 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors"
              aria-label="Close search"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          )}
        </div>

        {/* Advanced filter popover */}
        {searchExpanded && (
          <div className="absolute top-[calc(100%+8px)] left-0 right-0 z-[200] rounded-xl border border-gray-200 bg-white shadow-[0_8px_30px_rgba(15,23,42,0.12)] max-h-[70vh] overflow-y-auto">
            {isEmployer ? (
              <CandidateFilter
                variant="popover"
                filters={candidateFilters}
                onFilterChange={handleCandidateFilterChange}
                onClearFilters={handleClearCandidateFilters}
                showFilters={showSearchFilters}
                setShowFilters={setShowSearchFilters}
                suppressFields={['candidateName']}
              />
            ) : (
              <JobFilter
                variant="popover"
                filters={jobFilters}
                onFilterChange={handleJobFilterChange}
                onClearFilters={handleClearJobFilters}
                onApplyFilters={handleApplyJobFilters}
                showFilters={showSearchFilters}
                setShowFilters={setShowSearchFilters}
                suppressFields={['jobTitle']}
              />
            )}
          </div>
        )}
      </div>

      {/* Right: conditional auth actions */}
      <div className="flex shrink-0 items-center gap-2">
        {isSignedIn ? (
          <>
            {/* Role-based navigation buttons */}
            {navButtons.map((btn) => {
              const isActive = location.pathname === btn.path
              return (
                <button
                  key={btn.path}
                  type="button"
                  onClick={() => navigate(btn.path)}
                  className={`cursor-pointer rounded-full border-0 px-4 py-2 text-[1.05rem] font-semibold transition-all ${
                    isActive
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-transparent text-slate-800 hover:bg-blue-50 hover:text-blue-700'
                  }`}
                >
                  {btn.label}
                </button>
              )
            })}

            {/* Notification bell */}
            <div className="relative" ref={notificationsRef}>
              <button
                type="button"
                onClick={() => setNotificationsOpen((prev) => !prev)}
                className="flex h-[38px] w-[38px] cursor-pointer items-center justify-center rounded-full border-[1.5px] border-slate-200 bg-white text-slate-600 transition-colors hover:border-blue-200 hover:bg-slate-100 hover:text-blue-700"
                aria-label="Notifications"
                aria-expanded={notificationsOpen}
              >
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                  <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                </svg>
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[0.65rem] font-bold text-white">
                    {unreadCount}
                  </span>
                )}
              </button>

              {notificationsOpen && (
                <div className="absolute top-[calc(100%+10px)] right-0 z-[200] min-w-[320px] rounded-xl border border-gray-200 bg-white p-0 shadow-[0_8px_30px_rgba(15,23,42,0.12)]">
                  <div className="border-b border-gray-100 px-4 py-3">
                    <h3 className="text-[0.95rem] font-semibold text-slate-900">Notifications</h3>
                  </div>
                  <ul className="m-0 max-h-[320px] list-none overflow-y-auto p-0">
                    {MOCK_NOTIFICATIONS.map((notification) => (
                      <li
                        key={notification.id}
                        className={`cursor-pointer border-b border-gray-50 px-4 py-3 transition-colors last:border-b-0 hover:bg-slate-50 ${notification.unread ? 'bg-blue-50/50' : ''}`}
                      >
                        <p className="m-0 text-[0.9rem] leading-snug text-slate-800">{notification.text}</p>
                        <p className="m-0 mt-1 text-[0.75rem] text-slate-500">{notification.time}</p>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* User avatar + dropdown */}
            <div className="relative" ref={dropdownRef}>
              <button
                type="button"
                className="flex h-[38px] w-[38px] cursor-pointer items-center justify-center rounded-full border-2 border-slate-200 bg-blue-700 p-0 text-white transition-[border-color,box-shadow] hover:border-blue-600 hover:shadow-[0_0_0_3px_rgba(37,99,235,0.18)]"
                aria-label="User profile"
                aria-expanded={dropdownOpen}
                onClick={() => setDropdownOpen((prev) => !prev)}
              >
                <span className="text-[0.9rem] leading-none font-bold" aria-hidden="true">
                  U
                </span>
              </button>

              {dropdownOpen && (
                <ul
                  className="absolute top-[calc(100%+10px)] right-0 z-[200] m-0 min-w-[200px] list-none rounded-xl border border-gray-200 bg-white p-1.5 shadow-[0_8px_30px_rgba(15,23,42,0.12)]"
                  role="menu"
                >
                  {dropdownItems.map((item) => (
                    <li key={item.key} role="none">
                      <button
                        type="button"
                        role="menuitem"
                        className={dropdownItemClass}
                        onClick={() => {
                          setDropdownOpen(false)
                          if (item.path) navigate(item.path)
                        }}
                      >
                        {item.label}
                      </button>
                    </li>
                  ))}
                  <li role="none" className="mx-1.5 my-1 h-px bg-gray-200" />
                  <li role="none">
                    <button
                      type="button"
                      role="menuitem"
                      className={dropdownSignOutClass}
                      onClick={handleSignOut}
                    >
                      Sign Out
                    </button>
                  </li>
                </ul>
              )}
            </div>
          </>
        ) : (
          <button
            type="button"
            className="cursor-pointer rounded-full border-0 bg-blue-700 px-[22px] py-[9px] text-[0.92rem] font-bold text-white transition-[background-color,box-shadow] hover:bg-blue-600 hover:shadow-[0_4px_14px_rgba(37,99,235,0.3)]"
            onClick={() => navigate('/login')}
          >
            Join Now
          </button>
        )}
      </div>
    </header>
  )
}

export default Navbar
